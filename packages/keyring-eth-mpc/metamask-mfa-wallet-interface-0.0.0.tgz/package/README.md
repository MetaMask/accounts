# `@metamask/mfa-wallet-interfaces`

Interfaces for the MetaMask MFA Wallet SDK.

## Installation

`yarn add @metamask/mfa-wallet-interfaces`

or

`npm install @metamask/mfa-wallet-interfaces`

## Contributing

This package is part of a monorepo. Instructions for contributing can be found in the [monorepo README](https://github.com/MetaMask/mfa-wallet-sdk#readme).

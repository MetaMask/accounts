# @metamask/mfa-wallet-network

Network transport layer for the MetaMask MFA Wallet SDK.

## Overview

This package provides the transport layer for multi-party communication in the MFA Wallet SDK. It includes:

- **MfaSession**: Session abstraction for party-to-party messaging
- **createP2PChannelAdapter**: Routes messages through dedicated pair channels
- **WebSocketTransport**: Production transport using Centrifuge WebSocket protocol

## Installation

```bash
yarn add @metamask/mfa-wallet-network
```

or

```bash
npm install @metamask/mfa-wallet-network
```

## Usage

### Basic Session Setup

```typescript
import {
  MfaSession,
  WebSocketTransport,
  createP2PChannelAdapter,
} from '@metamask/mfa-wallet-network';

// Create and connect transport
const transport = new WebSocketTransport({
  url: 'wss://your-centrifuge-server.com/connection/websocket',
});
await transport.connect();

// Create P2P adapter for this party
const adapter = createP2PChannelAdapter(transport, 'party-a');

// Create session
const session = new MfaSession('session-123', 'party-a', adapter);

// Send and receive messages
session.sendMessage('party-b', 'greeting', new TextEncoder().encode('Hello'));
const message = await session.receiveMessage('party-b', 'response');

// Cleanup
await session.disconnect();
```

### Multi-Party Communication

```typescript
// Each party creates their own session with the same sessionId
const sessionA = new MfaSession('dkg-round-1', 'alice', adapterA);
const sessionB = new MfaSession('dkg-round-1', 'bob', adapterB);

// Alice sends to Bob
sessionA.sendMessage('bob', 'round1', data);

// Bob receives from Alice
const fromAlice = await sessionB.receiveMessage('alice', 'round1');
```

### Subsessions

```typescript
// Create subsession for nested protocol rounds
const mainSession = new MfaSession('dkg', 'alice', adapter);
const subSession = mainSession.createSubsession('round-2');

// Subsession has sessionId 'dkg-round-2'
subSession.sendMessage('bob', 'msg', data);
```

## API Reference

### MfaSession

Session class implementing `NetworkSession` interface.

```typescript
class MfaSession {
  constructor(
    sessionId: SessionId,
    selfId: PartyId,
    transport: Transport<PartyMessage>,
  );

  readonly sessionId: SessionId;
  readonly selfId: PartyId;

  sendMessage(
    receiver: PartyId,
    messageType: MessageType,
    message: Uint8Array,
  ): void;
  receiveMessage(
    sender: PartyId,
    messageType: MessageType,
  ): Promise<Uint8Array>;
  createSubsession(subSessionId: SessionId): NetworkSession;
  disconnect(): Promise<void>;
}
```

### createP2PChannelAdapter

Creates an adapter that routes messages through pair-specific channels.

```typescript
function createP2PChannelAdapter(
  transport: Transport<ChannelMessage<PartyMessage>>,
  selfId: string,
): Transport<PartyMessage>;
```

### getDirectionalChannel

Generates directional channel names for message routing.

```typescript
getDirectionalChannel('alice', 'bob', 'session-1'); // '["p2p","session-1","alice","bob"]'
getDirectionalChannel('bob', 'alice', 'session-1'); // '["p2p","session-1","bob","alice"]'
```

### WebSocketTransport

Production transport using Centrifuge protocol.
Channels are published/subscribed under the `mfa` namespace by default (for example `mfa:<channel>` on the wire).

```typescript
class WebSocketTransport<Payload> {
  constructor(options: WebSocketTransportOptions);
}

type WebSocketTransportOptions = {
  url: string;
  websocket?: unknown;
  network?: NetworkConfig;
};
```

## Message Format

```typescript
type PartyMessage = {
  i: SessionId; // session identifier
  f: PartyId; // from (sender)
  t: PartyId; // to (receiver)
  m: MessageType; // message type
  p: Uint8Array; // payload
};
```

## License

MIT

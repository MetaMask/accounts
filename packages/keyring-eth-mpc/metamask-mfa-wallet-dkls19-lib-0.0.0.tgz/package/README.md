# `@metamask/mfa-wallet-dkls19-lib`

DKLS19 library for the MetaMask MFA Wallet SDK.

## Installation

`yarn add @metamask/mfa-wallet-dkls19-lib`

or

`npm install @metamask/mfa-wallet-dkls19-lib`

## Contributing

This package is part of a monorepo. Instructions for contributing can be found in the [monorepo README](https://github.com/MetaMask/mfa-wallet-sdk#readme).

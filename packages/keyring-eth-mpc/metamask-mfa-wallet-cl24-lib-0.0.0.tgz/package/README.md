# `@metamask/mfa-wallet-cl24-lib`

Implementation of distributed key management protocols based on Chen-Lindell-24 for the MetaMask MFA Wallet SDK.

References:

- [Chen-Lindell-24 (CL24)](https://cic.iacr.org/p/1/1/16)
- [cb-mpc/ec-dkg-theory](https://github.com/coinbase/cb-mpc/blob/d2a3b9b38f17b1fe41c3923e0a10d956adfdeffc/docs/theory/ec-dkg-theory.pdf)
- [cb-mpc/ec-dkg-spec](https://github.com/coinbase/cb-mpc/blob/d2a3b9b38f17b1fe41c3923e0a10d956adfdeffc/docs/spec/ec-dkg-spec.pdf)

## Installation

`yarn add @metamask/mfa-wallet-cl24-lib`

or

`npm install @metamask/mfa-wallet-cl24-lib`

## Contributing

This package is part of a monorepo. Instructions for contributing can be found in the [monorepo README](https://github.com/MetaMask/mfa-wallet-sdk#readme).

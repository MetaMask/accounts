# @metamask/mfa-wallet-e2ee

End-to-end encryption for multi-party MFA wallet sessions using the Noise Protocol Framework.

## Overview

This package provides secure pairwise encryption between parties in a multi-party session. It includes:

- **PeerEncryption**: Manages encrypted channels with all parties in a session
- **performNoiseHandshake**: Transport-agnostic Noise KK handshake function
- **NoiseProtocol**: Full implementation of the Noise Protocol Framework
- **Handshake Pattern**: Support for the KK pattern only

## Installation

```bash
yarn add @metamask/mfa-wallet-e2ee
```

or

```bash
npm install @metamask/mfa-wallet-e2ee
```

## Usage

### Basic Peer Encryption Usage

```typescript
import { PeerEncryption, type RandomBytes } from '@metamask/mfa-wallet-e2ee';
import { webcrypto } from 'crypto';

const randomBytes: RandomBytes = webcrypto;

// Create peer encryption instance for each party
const encryptionAlice = new PeerEncryption({
  selfId: 'alice',
  randomBytes,
  staticKeyPair: aliceKeyPair,
  getRemotePublicKey: async (partyId) => lookupPublicKey(partyId),
});
const encryptionBob = new PeerEncryption({
  selfId: 'bob',
  randomBytes,
  staticKeyPair: bobKeyPair,
  getRemotePublicKey: async (partyId) => lookupPublicKey(partyId),
});

// Initialize with a transport for message I/O
await encryptionAlice.initialize(transport);
await encryptionBob.initialize(transport);

// Send an encrypted message (handshake happens automatically)
const plaintext = new TextEncoder().encode('Hello Bob!');
await encryptionAlice.send('bob', 'chat', plaintext);

// Receive and decrypt the message
const decrypted = await encryptionBob.receive('alice', 'chat');
// decrypted equals plaintext
```

### PeerTransport Interface

The transport provides raw message I/O used for both handshakes and encrypted data:

```typescript
type PeerTransport = {
  send(receiver: string, messageType: string, data: Uint8Array): Promise<void>;
  receive(sender: string, messageType: string): Promise<Uint8Array>;
};
```

### Noise Protocol Direct Usage

```typescript
import { NoiseProtocol, type RandomBytes } from '@metamask/mfa-wallet-e2ee';
import { webcrypto } from 'crypto';

const randomBytes: RandomBytes = webcrypto;

// Generate key pairs
const aliceStatic = await NoiseProtocol.generateKeyPair(randomBytes);
const bobStatic = await NoiseProtocol.generateKeyPair(randomBytes);

// Initialize handshakes (KK pattern - both parties know each other's static keys)
const aliceHandshake = await NoiseProtocol.initialize({
  randomBytes,
  initiator: true,
  staticKeyPair: aliceStatic,
  remoteStaticPublicKey: bobStatic.publicKey,
});

const bobHandshake = await NoiseProtocol.initialize({
  randomBytes,
  initiator: false,
  staticKeyPair: bobStatic,
  remoteStaticPublicKey: aliceStatic.publicKey,
});

// Exchange handshake messages
const msg1 = await aliceHandshake.writeMessage(new Uint8Array(0));
await bobHandshake.readMessage(msg1);

const msg2 = await bobHandshake.writeMessage(new Uint8Array(0));
await aliceHandshake.readMessage(msg2);

// Split into transport ciphers
const aliceCiphers = await aliceHandshake.split();
const bobCiphers = await bobHandshake.split();

// Use ciphers for transport encryption
const plaintext = new TextEncoder().encode('Hello!');
const encrypted = await aliceCiphers.tx.encrypt(plaintext);
const decrypted = await bobCiphers.rx.decrypt(encrypted);
```

## API Reference

### PeerEncryption

Manages end-to-end encryption with multiple peers. Handles both Noise KK handshakes
and encrypted message send/receive through a unified interface.

```typescript
class PeerEncryption implements EncryptionProvider {
  constructor(config: PeerEncryptionConfig);

  initialize(transport: PeerTransport): Promise<void>;
  send(
    receiver: PartyId,
    messageType: MessageType,
    message: Uint8Array,
  ): Promise<void>;
  receive(sender: PartyId, messageType: MessageType): Promise<Uint8Array>;
  getCipher(partyId: PartyId): SplitResult | undefined;
  waitForParty(partyId: PartyId, timeoutMs?: number): Promise<void>;
}
```

### performNoiseHandshake

Transport-agnostic function to perform a Noise KK handshake.

```typescript
function performNoiseHandshake(
  config: NoiseHandshakeConfig,
  io: HandshakeIO,
): Promise<SplitResult>;
```

### NoiseProtocol

Entry point for the Noise Protocol Framework using the KK pattern.

```typescript
class NoiseProtocol {
  static generateKeyPair(
    randomBytes: RandomBytes,
    dhFunction?: string,
  ): Promise<KeyPair>;
  static initialize(config: NoiseConfig): Promise<HandshakeState>;
  static getProtocolName(dh?: string, cipher?: string, hash?: string): string;
}
```

### Supported Patterns

Only the `KK` pattern is supported.

## Security

This package uses:

- **X25519** for Diffie-Hellman key exchange
- **ChaCha20-Poly1305** for authenticated encryption
- **SHA-256** for hashing

All implementations use `@noble/ciphers`, `@noble/curves`, and `@noble/hashes` for cryptographic primitives.

## License

MIT

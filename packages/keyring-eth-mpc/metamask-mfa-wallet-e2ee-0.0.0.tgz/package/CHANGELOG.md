# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Initial release ([#10](https://github.com/MetaMask/mfa-wallet-sdk/pull/10))
  - `PeerEncryption` - Unified E2EE manager handling both Noise KK handshakes and encrypted message I/O
  - `performNoiseHandshake` - Transport-agnostic Noise KK handshake function
  - `NoiseProtocol` - Full implementation of the Noise Protocol Framework
  - KK handshake pattern (mutually authenticated, forward secret)
  - Cipher cache sharing between parent sessions and subsessions
  - X25519 Diffie-Hellman key exchange
  - ChaCha20-Poly1305 AEAD encryption
  - SHA-256 hashing

[Unreleased]: https://github.com/MetaMask/mfa-wallet-sdk/
